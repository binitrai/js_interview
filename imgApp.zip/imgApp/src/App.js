import {Route, Routes, BrowserRouter} from "react-router-dom";
import Layout from "./components/Layout/Layout";
import SearchPage from "./pages/SearchPage/SearchPage";
import TrendingPage from "./pages/TredningPage/TrendingPage";
import Navigation from "./components/Layout/Navigation/Navigation";
import {ThemeProvider} from "./utils/ThemeContext";

function App() {
  return (
      <BrowserRouter>
        <ThemeProvider>
          <Navigation />
            <Layout>
              <Routes>
                <Route  path="/" element={<SearchPage />}/>
                <Route  path="/trending" element={<TrendingPage />}/>
              </Routes>
            </Layout>
        </ThemeProvider>
      </BrowserRouter>
  );
}

export default App;
