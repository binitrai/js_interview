import React, { useEffect, useRef, useState, useContext} from "react";
import { ThemeContext } from "../../utils/ThemeContext";

const ImageCard = ({imageSrc, user, embed_url, imageSrcStill}) => {
    const [spanStyle, setSpanStyle] = useState(0);
    const [showEmbedURL, setShowEmbedURL] = useState(false)
    const imageRef = useRef();
    const theme = useContext(ThemeContext);
    const still_gifs = theme.state.still_gifs;
    useEffect(() => {
        imageRef.current.addEventListener("load", setSpans)
    }, [])

    const setSpans = () => {
        console.log("setSpans")
        const height = imageRef.current.clientHeight;
        const spans = Math.ceil(height / 10) + 10;
        setSpanStyle(spans);
    };

    const handleClick =() => {
        setShowEmbedURL(true)
    }

    return (
        <div style={{ gridRowEnd: `span ${spanStyle}` }} className="ImgCard">
            <img ref={imageRef} src={still_gifs ? imageSrcStill : imageSrc}/>
            <span>Uploaded by : {user}</span>
            <button onClick={handleClick}>View Embed URL</button>
            {showEmbedURL ? <span>{embed_url}</span> : ""}
        </div>
    );

}

export default ImageCard