import React from "react";
import {NavLink} from "react-router-dom"
function NavigationItems() {
    return (
        <>
            <NavLink to="/" className={({ isActive }) => (isActive ? "active link" : "link")}>
                Home
            </NavLink>
            <NavLink to="/trending" className={({ isActive }) => (isActive ? "active link" : "link")}>
                Tredning
            </NavLink>
        </>
    )
}

export default NavigationItems;