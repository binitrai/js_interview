import React, {useContext} from "react";
import NavigationItems from "./NavigationItems";
import "./Navigation.css";
import {ThemeContext} from "../../../utils/ThemeContext";
import {UI_ACTIONS} from "../../../utils/uiReducer";

function Navigation() {
    const theme = useContext(ThemeContext);
    const still_gifs = theme.state.still_gifs;
    const handleClick = () => {
        theme.dispatch({type : UI_ACTIONS.SET_STILL_IMAGE, value : !still_gifs})
    }
    return (
        <header className="AppHeader">
            <div className="AppLogo">
                Image search app
            </div>
            <button onClick={handleClick}>{still_gifs ? "Loop" : "Still"}</button>
            <nav className="NavContainer">
                <NavigationItems />
            </nav>
        </header>
    )
}

export default Navigation;