import React from "react";

import ImagCard from "../ImagCard/ImagCard";
import "./ImageList.css";

function ImageList({images}) {
    return (
        <section className="ImageList">
            {
                images.map(_image => {
                    return (
                        <ImagCard 
                            key={_image.id}
                            imageSrc={_image.images.downsized_medium.url}
                            imageSrcStill={_image.images.downsized_still.url}
                            user = {_image.user && _image.user.display_name || ""}
                            embed_url = {_image.embed_url}
                        />
                    )
                })
            }
        </section>
    )
}

export default ImageList;
