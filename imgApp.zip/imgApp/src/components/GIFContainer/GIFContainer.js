import React, {useEffect, useReducer, useRef} from "react";

import fetchImages from "../../api/getImages";
import {imgReducer, IMAGE_ACTIONS, getImgInitialState} from "../../utils/imageReducer";

// for infinite scroll
import { pageReducer, getPageInitialState} from "../../utils/pageReducer";
import {useInfiniteScroll} from "../../utils/useINFSCROLL";

import ImageList from "../ImageList/ImageList";

function GIFContainer({
    query,
    trending = false
}) {
    const [imgState, dispatchImg] = useReducer(imgReducer, getImgInitialState());
    const {
        fetching_image,
        images,
        empty_response,
        fetch_error,
        errorMsg
    } = imgState;

    // forInfiniteScroll
    let bottomBoundaryRef = useRef(null);
    const [pager, pagerDispatch] = useReducer(pageReducer, getPageInitialState());
    const {page} = pager;
    useInfiniteScroll(bottomBoundaryRef, pagerDispatch);

    useEffect(() => {
        if (query || trending) {
            dispatchImg({type : IMAGE_ACTIONS.FETCHING_IMAGE})
            fetchImages({q : query, endPoint : trending ? "trending" : "search", offset : page * 20}).then(res => {
                dispatchImg({type : IMAGE_ACTIONS.UPDATE_IMAGE, images : res.data.data})
            }).catch(e => {
                dispatchImg({type : IMAGE_ACTIONS.FETCH_ERROR, errorMsg : e})
            })
        }
    }, [query, trending, page])

    return (
        <section className="GIFContainer">
            <h3>GIF GRID</h3>
            {
                fetching_image && <h4>Loading Images</h4>
            }
            {
                images.length && <ImageList images={images}/>
            }
            {
                empty_response && <h4>No Image Found</h4>
            }
            {
                fetch_error && <h4>{errorMsg}</h4>
            }

            <div id='page-bottom-boundary' style={{ border: '1px solid red' }} ref={bottomBoundaryRef}></div>
        </section>
    )
}

export default GIFContainer;