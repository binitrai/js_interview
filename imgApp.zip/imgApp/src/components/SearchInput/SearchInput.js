import React from "react";
import "./SearchInput.css";

function SearchInput({value, handleChange, id="searchInput"}) {
    return (
        <section className="SearchInput">
            <input 
                type="text"
                className="SearchInputText"
                placeholder="Search photos"
                id={id}
                value={value}
                onChange={handleChange}
            />
        </section>
    )
}

export default SearchInput