const PAGE_ACTIONS = {
    NEXT_PAGE : "NEXT_PAGE"
}

const getPageInitialState = () => {
    return {
        page : 0
    }
}

const pageReducer = (state, action) => {
    switch(action.type) {
        case PAGE_ACTIONS.NEXT_PAGE : 
            return {
                ...state,
                page : state.page + 1
            }
        default : 
            return state;
    }
}

export {
    pageReducer,
    getPageInitialState,
    PAGE_ACTIONS
}