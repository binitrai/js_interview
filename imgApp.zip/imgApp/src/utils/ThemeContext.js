import React, {createContext, useReducer} from "react"
import { uiReducer, getUIInitialState} from "./uiReducer";
export function ThemeProvider(props) {
    const [state, dispatch] = useReducer(uiReducer, getUIInitialState());
    return <ThemeContext.Provider 
                value={{ state: state, dispatch: dispatch }}>
                    {props.children}
            </ThemeContext.Provider>;
  }

export const ThemeContext = createContext()