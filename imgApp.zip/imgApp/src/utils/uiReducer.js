const UI_ACTIONS = {
    "SET_STILL_IMAGE" : "SET_STILL_IMAGE"
}

const getUIInitialState = () => {
    return {
        still_gifs : false
    }
}

const uiReducer = (state, action) => {
    switch(action.type) {
        case UI_ACTIONS.SET_STILL_IMAGE : 
            return {
                ...state,
                still_gifs : action.value
            }
        default : 
            return state;
    }
}

export {
    UI_ACTIONS,
    getUIInitialState,
    uiReducer
}