const IMAGE_ACTIONS = {
    FETCHING_IMAGE : "FETCHING_IMAGE",
    UPDATE_IMAGE : "UPDATE_IMAGE",
    FETCH_ERROR : "FETCH_ERROR",
    NO_IMG_FOUND : "NO_IMG_FOUND"
}

const getImgInitialState = () => {
    return {
        images : [],
        fetching_image : false,
        empty_response : false,
        fetch_error : false,
        errorMsg : ""
    }
}

const imgReducer = (state, action) => {
    switch(action.type) {
        case IMAGE_ACTIONS.FETCHING_IMAGE : 
            return {
                ...state,
                fetching_image : true,
                empty_response : false
            }

         case IMAGE_ACTIONS.UPDATE_IMAGE : 
            return {
                ...state,
                images : state.images.concat(action.images),
                fetch_error : false,
                fetching_image : false,
                empty_response : false
            }
        case IMAGE_ACTIONS.FETCH_ERROR : 
            return {
                ...state,
                fetch_error : true,
                errorMsg : action.errorMsg,
                fetching_image : false,
                empty_response : false
            }
        case IMAGE_ACTIONS.NO_IMG_FOUND : 
            return {
                ...state,
                fetching_image : false,
                empty_response : true
            }
        default : 
            return state;
    }
}

export {
    imgReducer,
    getImgInitialState,
    IMAGE_ACTIONS
}