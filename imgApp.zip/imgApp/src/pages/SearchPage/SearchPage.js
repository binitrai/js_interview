import React, {useState, useEffect} from "react";

import SearchInput from "../../components/SearchInput/SearchInput";
import GIFContainer from "../../components/GIFContainer/GIFContainer";
import ImageList from "../../components/ImageList/ImageList";
import fetchImages from "../../api/getImages";
import "./SearchPage.css";


function SearchPage() {
    const [value, setValue] = useState("");
    const [query, setQuery] = useState("");

    const handleChange = (e) => {
        setValue(e.target.value);
    }

    const handleSearch = () => {
        setQuery(value);
    }

    // useEffect(() => {
    //     fetchImages({endPoint: "search", q : value}).then(res => {
    //         setImages(res.data.data);
    //     })
    // }, [value])

    return (
        <>
            <h3>Search Page</h3>
            <SearchInput 
                value = {value} 
                handleChange={handleChange} 
            />
            <button onClick={handleSearch}>Search</button>
            {
                query &&  <GIFContainer query = {query} />
            }
           
            {/* <ImageList 
                images={images}
            /> */}
        </>
        
    )
}
export default SearchPage;