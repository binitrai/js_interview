import React from "react";
import GIFContainer from "../../components/GIFContainer/GIFContainer";

function TredningPage() {
    return (
        <>
            <h1>Tredning Page</h1>
            <GIFContainer trending = {true}/>
        </>
    )
}
export default TredningPage;