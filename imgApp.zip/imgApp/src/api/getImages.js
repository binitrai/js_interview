import axios from "axios";

const APIBASEURL = "https://api.giphy.com/v1/gifs/";

const APIENDPOINTS = {
    trending : "trending",
    search : "search"
}

const API_KEY = "5pz3ijoel9TP8PVJPb0SDND5kdXihPyc"
const getAPIURL = (endPoint) => {
    return APIBASEURL + APIENDPOINTS[endPoint];
}

const getParams = ({q, limit, offset}) => {
    let params = {
        api_key : API_KEY,
        limit : limit || 20,
        offset : offset || 0
    }
    if (q) {
        params.q = q
    }
    return params;
}

async function fetchImages({endPoint, q, limit = 20, offset = 0}) {
    const APIURL = getAPIURL(endPoint);
    const params = getParams({q, limit, offset})
    return axios.get(APIURL, {params}).catch(e => {
        throw new Error(e);
    })
}

export default fetchImages;